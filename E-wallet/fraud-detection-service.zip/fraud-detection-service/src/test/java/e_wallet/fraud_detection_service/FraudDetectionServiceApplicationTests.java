package e_wallet.fraud_detection_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudDetectionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
